import numpy as np

def vertexShader(vertex, **kwargs):
    # Se lleva a cabo por vertice

    # Recibimos las matrices
    modelMatrix = kwargs.get("modelMatrix")
    viewMatrix = kwargs.get("viewMatrix") 
    projectionMatrix = kwargs.get("projectionMatrix")
    viewportMatrix = kwargs.get("viewportMatrix")

    # Agregamos un componente W al vertice
    vt = [vertex[0],
          vertex[1],
          vertex[2],
          1]

    # Transformamos el vertices por todas las matrices en el orden correcto
    # Orden: Model -> View -> Projection -> Viewport
    if modelMatrix is not None:
        vt = modelMatrix @ vt
    
    if viewMatrix is not None:
        vt = viewMatrix @ vt
        
    if projectionMatrix is not None:
        vt = projectionMatrix @ vt
        
    # Dividir por W para proyección perspectiva
    if vt[3] != 0:
        vt = [vt[0] / vt[3], vt[1] / vt[3], vt[2] / vt[3], 1]
    
    if viewportMatrix is not None:
        vt = viewportMatrix @ vt

    vt = vt.tolist()[0] if hasattr(vt, 'tolist') else vt

    # Dividimos x,y,z por w para regresar el vertices a un tamaño de 3
    vt = [vt[0] / vt[3] if vt[3] != 0 else vt[0],
          vt[1] / vt[3] if vt[3] != 0 else vt[1],
          vt[2] / vt[3] if vt[3] != 0 else vt[2]]

    return vt


def simpleVertexShader(vertex, **kwargs):
    """Shader más simple para debugging"""
    modelMatrix = kwargs.get("modelMatrix")
    
    vt = [vertex[0], vertex[1], vertex[2], 1]
    
    if modelMatrix is not None:
        vt = modelMatrix @ vt
        vt = vt.tolist()[0]
        vt = [vt[0] / vt[3], vt[1] / vt[3], vt[2] / vt[3]]
    
    return vt
